import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Quiz from './components/Quiz';
import Result from './components/Result';
import { PerfumeFamily } from './data/quizData';
import { Sparkles, ArrowRight } from 'lucide-react';

type AppState = 'landing' | 'quiz' | 'result';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>('landing');
  const [scores, setScores] = useState<Record<PerfumeFamily, number> | null>(null);

  const handleQuizComplete = (finalScores: Record<PerfumeFamily, number>) => {
    setScores(finalScores);
    setState('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRestart = () => {
    setScores(null);
    setState('landing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans selection:bg-black selection:text-white">
      {/* Navigation / Header */}
      <nav className="fixed top-0 left-0 w-full z-50 px-8 py-6 flex justify-between items-center bg-white/80 backdrop-blur-sm">
        <div className="text-xl font-light tracking-[0.4em] uppercase">
          Scent <span className="font-bold">DNA</span>
        </div>
        <div className="hidden md:flex space-x-8 text-[10px] tracking-[0.3em] uppercase text-gray-400">
          <span>Discovery</span>
          <span>Profile</span>
          <span>Essence</span>
        </div>
      </nav>

      <main className="pt-24 pb-20">
        <AnimatePresence mode="wait">
          {state === 'landing' && (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-4xl mx-auto px-6 py-20 text-center"
            >
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="mb-12 inline-flex items-center px-4 py-2 rounded-full border border-gray-100 text-[10px] tracking-[0.2em] uppercase text-gray-400"
              >
                <Sparkles className="w-3 h-3 mr-2" />
                Find Your Signature Scent
              </motion.div>

              <motion.h1
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-6xl md:text-8xl font-light tracking-tighter mb-12 leading-[0.9]"
              >
                闻见你自己
              </motion.h1>

              <motion.p
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="text-lg text-gray-500 font-light max-w-xl mx-auto mb-16 leading-relaxed"
              >
                通过10个关于性格、日常与内在的深度提问，<br />
                为你匹配最契合的香氛灵魂。
              </motion.p>

              <motion.button
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.8 }}
                onClick={() => setState('quiz')}
                className="group relative inline-flex items-center px-12 py-5 bg-black text-white text-sm tracking-[0.3em] uppercase overflow-hidden transition-all duration-500 hover:pr-16"
              >
                <span className="relative z-10">开始测试 / Start Quiz</span>
                <ArrowRight className="absolute right-6 w-5 h-5 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-x-[-10px] group-hover:translate-x-0" />
              </motion.button>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.2 }}
                className="mt-32 grid grid-cols-2 md:grid-cols-4 gap-8 opacity-20 grayscale"
              >
                {['Floral', 'Woody', 'Oriental', 'Citrus'].map((tag) => (
                  <div key={tag} className="text-[10px] tracking-[0.4em] uppercase font-medium">
                    {tag}
                  </div>
                ))}
              </motion.div>
            </motion.div>
          )}

          {state === 'quiz' && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <Quiz onComplete={handleQuizComplete} />
            </motion.div>
          )}

          {state === 'result' && scores && (
            <motion.div
              key="result"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <Result scores={scores} onRestart={handleRestart} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer Decoration */}
      <footer className="fixed bottom-0 left-0 w-full px-8 py-6 flex justify-between items-end pointer-events-none">
        <div className="text-[8px] tracking-[0.5em] uppercase text-gray-300 vertical-text">
          Est. 2026
        </div>
        <div className="text-[8px] tracking-[0.5em] uppercase text-gray-300">
          Minimalist Fragrance Discovery System
        </div>
      </footer>
    </div>
  );
};

export default App;
