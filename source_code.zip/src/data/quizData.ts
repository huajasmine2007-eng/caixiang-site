export type PerfumeFamily = 
  | 'Floral' 
  | 'Woody' 
  | 'Oriental' 
  | 'Citrus' 
  | 'Fresh' 
  | 'Gourmand' 
  | 'Chypre' 
  | 'Fougère';

export interface Recommendation {
  brand: string;
  model: string;
  description: string;
}

export interface ResultInfo {
  id: PerfumeFamily;
  name: string;
  description: string;
  reason: string;
  recommendations: Recommendation[];
}

export const perfumeResults: Record<PerfumeFamily, ResultInfo> = {
  Floral: {
    id: 'Floral',
    name: '花香调 (Floral)',
    description: '你如同盛开的花园，散发着温柔、浪漫且优雅的气息。你内心充满爱意，对生活中的美有着敏锐的洞察力。你的存在就像春日里的一缕阳光，让人感到亲切而舒适。',
    reason: '你的性格温婉，喜欢浪漫与和谐，外在风格偏向柔美，这与花香调中玫瑰、茉莉、铃兰等元素的甜美与纯净完美契合。',
    recommendations: [
      { brand: 'Dior', model: 'Miss Dior (花漾甜心)', description: '经典的玫瑰与牡丹交织，尽显少女的浪漫。' },
      { brand: 'Chanel', model: 'No. 5 (五号之水)', description: '现代化的花香，优雅而不失清新。' },
      { brand: 'Gucci', model: 'Bloom (繁花)', description: '仿佛置身于繁花盛开的秘密花园。' }
    ]
  },
  Woody: {
    id: 'Woody',
    name: '木质调 (Woody)',
    description: '你沉稳、内敛且极具质感。你像是一棵深扎大地的古树，给人以可靠和安定的力量。你追求深度，不随波逐流，拥有独立而坚定的内心世界。',
    reason: '你偏好极简与质感，性格冷静睿智，木质调中的檀香、雪松、香根草等元素能完美衬托出你的成熟与稳重。',
    recommendations: [
      { brand: 'Hermès', model: 'Terre d\'Hermès (大地)', description: '葡萄柚与木质香的结合，展现广阔的胸怀。' },
      { brand: 'Le Labo', model: 'Santal 33 (檀香33)', description: '独特的皮革与木质香，极具辨识度的中性美。' },
      { brand: 'Diptyque', model: 'Tam Dao (谭道)', description: '纯粹的檀香，带给人宁静的禅意。' }
    ]
  },
  Oriental: {
    id: 'Oriental',
    name: '东方调 (Oriental)',
    description: '你神秘、迷人且富有激情。你拥有强烈的个人魅力，像是一场华丽的冒险。你敢于表达自我，内心深处藏着无尽的能量与故事。',
    reason: '你追求独特与华丽，性格中带着一丝神秘感，东方调中辛辣的香料、琥珀、香草等元素能勾勒出你迷人的轮廓。',
    recommendations: [
      { brand: 'YSL', model: 'Black Opium (黑鸦片)', description: '咖啡与花香的碰撞，极具诱惑力的甜美。' },
      { brand: 'Tom Ford', model: 'Black Orchid (午夜兰花)', description: '深邃而复杂的香气，展现极致的奢华。' },
      { brand: 'Guerlain', model: 'Shalimar (一千零一夜)', description: '经典的东方香，浪漫而永恒。' }
    ]
  },
  Citrus: {
    id: 'Citrus',
    name: '柑橘调 (Citrus)',
    description: '你充满活力、阳光且清爽。你像是一颗刚切开的柠檬，瞬间点亮周围的空气。你热爱自由，性格开朗，总是能带给身边的人正能量。',
    reason: '你追求简单与自然，性格活泼好动，柑橘调中柠檬、佛手柑、橙花等元素的清爽感与你的生命力相得益彰。',
    recommendations: [
      { brand: 'Jo Malone', model: 'Lime Basil & Mandarin (青柠罗勒与柑橘)', description: '清新的柑橘与辛辣的罗勒，充满活力的平衡。' },
      { brand: 'Acqua di Parma', model: 'Colonia (克罗尼亚)', description: '经典的意式清新，阳光而优雅。' },
      { brand: 'Atelier Cologne', model: 'Orange Sanguine (赤霞橘光)', description: '多汁的血橙，仿佛捕捉到了夏日的阳光。' }
    ]
  },
  Fresh: {
    id: 'Fresh',
    name: '清新/水生调 (Fresh/Aquatic)',
    description: '你纯净、自然且随性。你像是一阵海风，或者清晨的露珠，给人以无限的遐想空间。你追求内心的平静，向往广阔的自然。',
    reason: '你热爱自然与自由，性格随和，水生调中的海洋、雨水、绿叶等元素能体现出你清爽脱俗的气质。',
    recommendations: [
      { brand: 'Davidoff', model: 'Cool Water (冷水)', description: '经典的海洋香，清爽而深邃。' },
      { brand: 'Giorgio Armani', model: 'Acqua di Gio (寄情)', description: '海风与花香的结合，自然而和谐。' },
      { brand: 'Issey Miyake', model: 'L\'Eau d\'Issey (一生之水)', description: '纯净的水生花香，极简而隽永。' }
    ]
  },
  Gourmand: {
    id: 'Gourmand',
    name: '美食调 (Gourmand)',
    description: '你甜美、可爱且富有童心。你像是一块精致的甜点，让人感到温暖与愉悦。你热爱生活中的小确幸，内心柔软而温暖。',
    reason: '你性格亲切，喜欢甜美的事物，美食调中的焦糖、巧克力、香草等元素能完美呼应你温暖可人的性格。',
    recommendations: [
      { brand: 'Prada', model: 'Candy (卡迪小姐)', description: '浓郁的焦糖与麝香，甜而不腻。' },
      { brand: 'Mugler', model: 'Angel (天使)', description: '开创性的美食调，充满个性的甜美。' },
      { brand: 'Viktor&Rolf', model: 'Flowerbomb (鲜花炸弹)', description: '花香与美食的完美融合，极具冲击力。' }
    ]
  },
  Chypre: {
    id: 'Chypre',
    name: '西普调 (Chypre)',
    description: '你经典、大胆且极具个性。你拥有复杂的层次感，像是一部耐人寻味的电影。你自信且独立，不畏惧展现自己的锋芒。',
    reason: '你追求深度与独特性，性格坚毅，西普调中橡木苔、佛手柑、广藿香的对比感能体现出你高冷而迷人的气质。',
    recommendations: [
      { brand: 'Chanel', model: 'Coco Mademoiselle (可可小姐)', description: '现代西普调的代表，优雅而大胆。' },
      { brand: 'Dior', model: 'Miss Dior Original (经典小姐)', description: '复古而高贵的西普香，展现极致的品味。' },
      { brand: 'Sisley', model: 'Eau du Soir (夜幕之水)', description: '奢华而复杂的香气，极具女王气场。' }
    ]
  },
  Fougère: {
    id: 'Fougère',
    name: '馥奇调 (Fougère)',
    description: '你传统、可靠且充满力量。你拥有经典的绅士/淑女风范，注重细节与品质。你像是一片茂密的森林，深邃而充满生机。',
    reason: '你性格稳重，追求品质，馥奇调中薰衣草、天竺葵、橡木苔等元素的草本感能体现出你干练而优雅的特质。',
    recommendations: [
      { brand: 'Dior', model: 'Sauvage (旷野)', description: '现代馥奇调的巅峰，狂野而精致。' },
      { brand: 'Guy Laroche', model: 'Drakkar Noir (黑色达卡)', description: '经典的男士馥奇香，充满力量感。' },
      { brand: 'Penhaligon\'s', model: 'Sartorial (裁缝)', description: '英伦绅士的代表，精致而考究。' }
    ]
  }
};

export interface Question {
  id: number;
  text: string;
  options: {
    text: string;
    scores: Partial<Record<PerfumeFamily, number>>;
  }[];
}

export const questions: Question[] = [
  {
    id: 1,
    text: '你的性格更倾向于？',
    options: [
      { text: '热情开朗，充满活力', scores: { Citrus: 3, Fresh: 1, Floral: 1 } },
      { text: '沉稳内敛，追求深度', scores: { Woody: 3, Chypre: 1, Fougère: 1 } },
      { text: '神秘优雅，迷人独特', scores: { Oriental: 3, Chypre: 1 } },
      { text: '随性自然，亲切温和', scores: { Fresh: 3, Floral: 1, Gourmand: 1 } }
    ]
  },
  {
    id: 2,
    text: '理想的周末，你更愿意？',
    options: [
      { text: '逛花店或美术馆', scores: { Floral: 3, Fresh: 1 } },
      { text: '森林徒步或安静阅读', scores: { Woody: 3, Fougère: 1 } },
      { text: '参加派对或去高级餐厅', scores: { Oriental: 3, Gourmand: 1 } },
      { text: '海边散步或户外运动', scores: { Fresh: 3, Citrus: 1 } }
    ]
  },
  {
    id: 3,
    text: '你的穿搭风格通常是？',
    options: [
      { text: '甜美、浪漫、多用柔和色', scores: { Floral: 3, Gourmand: 1 } },
      { text: '极简、质感、注重剪裁', scores: { Woody: 3, Chypre: 1 } },
      { text: '华丽、复古、富有设计感', scores: { Oriental: 3, Chypre: 1 } },
      { text: '休闲、运动、舒适大方', scores: { Citrus: 3, Fresh: 1 } }
    ]
  },
  {
    id: 4,
    text: '朋友们常形容你是一个？',
    options: [
      { text: '亲切的倾听者', scores: { Floral: 2, Fresh: 2, Gourmand: 1 } },
      { text: '可靠的行动派', scores: { Woody: 2, Fougère: 2, Citrus: 1 } },
      { text: '独特的思想家', scores: { Oriental: 2, Chypre: 2, Woody: 1 } },
      { text: '活力的开心果', scores: { Citrus: 3, Fresh: 1, Gourmand: 1 } }
    ]
  },
  {
    id: 5,
    text: '你最喜欢的季节是？',
    options: [
      { text: '万物复苏的春天', scores: { Floral: 3, Fresh: 1 } },
      { text: '宁静深沉的秋天', scores: { Woody: 3, Chypre: 1 } },
      { text: '温暖治愈的冬天', scores: { Oriental: 2, Gourmand: 3 } },
      { text: '阳光灿烂的夏天', scores: { Citrus: 3, Fresh: 2 } }
    ]
  },
  {
    id: 6,
    text: '哪种味道最能吸引你的注意？',
    options: [
      { text: '盛开的花朵香气', scores: { Floral: 3 } },
      { text: '雨后泥土与草木的气息', scores: { Woody: 2, Fresh: 2, Fougère: 1 } },
      { text: '辛辣的香料或琥珀味', scores: { Oriental: 3 } },
      { text: '刚切开的柠檬或橙子味', scores: { Citrus: 3 } }
    ]
  },
  {
    id: 7,
    text: '你对生活的追求是？',
    options: [
      { text: '充满爱与美的和谐', scores: { Floral: 3, Gourmand: 1 } },
      { text: '宁静与深度的自我实现', scores: { Woody: 3, Chypre: 1 } },
      { text: '激情与冒险的精彩人生', scores: { Oriental: 3, Fougère: 1 } },
      { text: '自由与简单的快乐', scores: { Fresh: 3, Citrus: 2 } }
    ]
  },
  {
    id: 8,
    text: '在社交场合中，你通常？',
    options: [
      { text: '照顾大家的情绪，温和周到', scores: { Floral: 2, Fresh: 2, Gourmand: 1 } },
      { text: '安静观察，适时发表见解', scores: { Woody: 2, Chypre: 2, Fougère: 1 } },
      { text: '展现魅力，成为焦点', scores: { Oriental: 3, Chypre: 1 } },
      { text: '轻松融入，随性自然', scores: { Citrus: 2, Fresh: 2, Floral: 1 } }
    ]
  },
  {
    id: 9,
    text: '你更偏好哪种触感或材质？',
    options: [
      { text: '柔软的丝绸或蕾丝', scores: { Floral: 3, Gourmand: 1 } },
      { text: '厚实的羊绒或原木', scores: { Woody: 3, Fougère: 1 } },
      { text: '华丽的丝绒或皮革', scores: { Oriental: 3, Chypre: 1 } },
      { text: '清爽的亚麻或纯棉', scores: { Fresh: 2, Citrus: 3 } }
    ]
  },
  {
    id: 10,
    text: '你希望给人的第一印象是？',
    options: [
      { text: '温柔可亲', scores: { Floral: 3, Gourmand: 1 } },
      { text: '睿智稳重', scores: { Woody: 3, Chypre: 1 } },
      { text: '迷人神秘', scores: { Oriental: 3, Fougère: 1 } },
      { text: '清爽自然', scores: { Fresh: 3, Citrus: 2 } }
    ]
  }
];
