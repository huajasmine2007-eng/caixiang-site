import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { questions, PerfumeFamily } from '../data/quizData';
import { ChevronRight, ChevronLeft } from 'lucide-react';

interface QuizProps {
  onComplete: (scores: Record<PerfumeFamily, number>) => void;
}

const Quiz: React.FC<QuizProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);

  const handleOptionSelect = (optionIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentStep] = optionIndex;
    setAnswers(newAnswers);

    if (currentStep < questions.length - 1) {
      setTimeout(() => setCurrentStep(currentStep + 1), 300);
    } else {
      calculateResults(newAnswers);
    }
  };

  const calculateResults = (finalAnswers: number[]) => {
    const scores: Record<PerfumeFamily, number> = {
      Floral: 0,
      Woody: 0,
      Oriental: 0,
      Citrus: 0,
      Fresh: 0,
      Gourmand: 0,
      Chypre: 0,
      Fougère: 0,
    };

    finalAnswers.forEach((answerIndex, questionIndex) => {
      const option = questions[questionIndex].options[answerIndex];
      Object.entries(option.scores).forEach(([family, score]) => {
        scores[family as PerfumeFamily] += score || 0;
      });
    });

    onComplete(scores);
  };

  const progress = ((currentStep + 1) / questions.length) * 100;

  return (
    <div className="max-w-2xl mx-auto px-6 py-12 min-h-[600px] flex flex-col">
      {/* Progress Bar */}
      <div className="w-full h-1 bg-gray-100 mb-12 overflow-hidden rounded-full">
        <motion.div 
          className="h-full bg-black"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="flex-grow flex flex-col"
        >
          <span className="text-sm font-medium text-gray-400 mb-4 tracking-widest uppercase">
            Question {currentStep + 1} / {questions.length}
          </span>
          
          <h2 className="text-3xl font-light text-gray-900 mb-12 leading-tight">
            {questions[currentStep].text}
          </h2>

          <div className="space-y-4">
            {questions[currentStep].options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionSelect(index)}
                className={`w-full text-left p-6 border transition-all duration-300 group relative overflow-hidden ${
                  answers[currentStep] === index 
                    ? 'border-black bg-black text-white' 
                    : 'border-gray-200 hover:border-black bg-white text-gray-700'
                }`}
              >
                <span className="relative z-10 text-lg font-light">{option.text}</span>
                {answers[currentStep] !== index && (
                  <div className="absolute inset-0 bg-black translate-y-full group-hover:translate-y-0 transition-transform duration-300 opacity-[0.02]" />
                )}
              </button>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>

      <div className="mt-12 flex justify-between items-center">
        <button
          onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
          disabled={currentStep === 0}
          className={`flex items-center text-sm tracking-widest uppercase transition-colors ${
            currentStep === 0 ? 'text-gray-200 cursor-not-allowed' : 'text-gray-400 hover:text-black'
          }`}
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Previous
        </button>
        
        <div className="text-xs text-gray-300 font-light tracking-widest uppercase">
          Minimalist Scent Discovery
        </div>
      </div>
    </div>
  );
};

export default Quiz;
