import React from 'react';
import { motion } from 'framer-motion';
import { PerfumeFamily, perfumeResults, ResultInfo } from '../data/quizData';
import { RefreshCw, Star, ArrowRight } from 'lucide-react';

interface ResultProps {
  scores: Record<PerfumeFamily, number>;
  onRestart: () => void;
}

const Result: React.FC<ResultProps> = ({ scores, onRestart }) => {
  // Sort scores to find top 3
  const sortedFamilies = (Object.entries(scores) as [PerfumeFamily, number][])
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3);

  const topResults = sortedFamilies.map(([family]) => perfumeResults[family]);
  const primaryResult = topResults[0];

  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <header className="mb-16 text-center">
          <span className="text-sm font-medium text-gray-400 tracking-[0.3em] uppercase mb-4 block">
            Your Scent Profile
          </span>
          <h1 className="text-5xl font-light text-gray-900 mb-6 tracking-tight">
            {primaryResult.name}
          </h1>
          <div className="w-12 h-[1px] bg-black mx-auto mb-8" />
        </header>

        <section className="mb-20">
          <p className="text-xl font-light text-gray-700 leading-relaxed mb-12 first-letter:text-4xl first-letter:font-serif first-letter:mr-2 first-letter:float-left">
            {primaryResult.description}
          </p>
          
          <div className="bg-gray-50 p-10 border-l-2 border-black">
            <h3 className="text-sm font-bold tracking-widest uppercase mb-4 text-gray-900">
              推荐原因 / The Reason
            </h3>
            <p className="text-gray-600 font-light leading-relaxed">
              {primaryResult.reason}
            </p>
          </div>
        </section>

        <section className="mb-20">
          <h3 className="text-sm font-bold tracking-widest uppercase mb-10 text-gray-900 border-b border-gray-100 pb-4">
            氛围契合度排名 / Atmosphere Ranking
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {topResults.map((result, index) => (
              <div key={result.id} className="relative group">
                <span className="absolute -top-4 -left-2 text-6xl font-serif text-gray-100 group-hover:text-gray-200 transition-colors z-0">
                  0{index + 1}
                </span>
                <div className="relative z-10 pt-4">
                  <h4 className="text-lg font-medium text-gray-900 mb-2">{result.name}</h4>
                  <p className="text-sm text-gray-500 font-light line-clamp-3">
                    {result.description.split('。')[0]}。
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="mb-20">
          <h3 className="text-sm font-bold tracking-widest uppercase mb-10 text-gray-900 border-b border-gray-100 pb-4">
            推荐香水型号 / Recommended Fragrances
          </h3>
          <div className="space-y-6">
            {primaryResult.recommendations.map((rec, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 * index }}
                className="flex flex-col md:flex-row md:items-center justify-between p-8 border border-gray-100 hover:border-black transition-all duration-500 group"
              >
                <div className="mb-4 md:mb-0">
                  <span className="text-sm font-bold text-black tracking-widest uppercase mb-1 block">
                    {rec.brand}
                  </span>
                  <h4 className="text-xl font-light text-gray-600 group-hover:text-black transition-all duration-500">
                    {rec.model}
                  </h4>
                </div>
                <div className="flex items-center text-gray-500 font-light text-sm italic">
                  <span>{rec.description}</span>
                  <ArrowRight className="w-4 h-4 ml-4 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-x-[-10px] group-hover:translate-x-0" />
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        <footer className="text-center pt-12 border-t border-gray-100">
          <button
            onClick={onRestart}
            className="inline-flex items-center px-10 py-4 bg-black text-white text-sm tracking-[0.2em] uppercase hover:bg-gray-800 transition-all duration-300 group"
          >
            <RefreshCw className="w-4 h-4 mr-3 group-hover:rotate-180 transition-transform duration-700" />
            重新测试 / Retake Quiz
          </button>
        </footer>
      </motion.div>
    </div>
  );
};

export default Result;
